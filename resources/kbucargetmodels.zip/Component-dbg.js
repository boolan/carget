sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("kbu.carget.models.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);